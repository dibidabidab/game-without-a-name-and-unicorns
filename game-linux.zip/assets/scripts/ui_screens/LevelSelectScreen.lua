
local txt = createEntity()

applyTemplate(txt, "Text", {
    text = "\n\nLevel Select screen:\nVery much coming soon (TM) // TODO"
})
