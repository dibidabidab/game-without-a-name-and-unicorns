####Sound effects used in the game

Click the (file)name to go to the original download page.
Most sound files are adapted from their original.

- [`arrow_shoot.ogg`](https://opengameart.org/content/sfxpunch) **by** (c) copyright Blender Foundation | apricot.blender.org [(CC BY 3.0)](https://creativecommons.org/licenses/by/3.0/)
- [`fire/fire0.ogg`](https://freesound.org/people/Dynamicell/sounds/17548/) **by** Dynamicell [(CC BY 3.0)](https://creativecommons.org/licenses/by/3.0/)
- [`arrow_block.ogg`](https://freesound.org/people/jorickhoofd/sounds/160043/) **by** jorickhoofd [(CC BY 3.0)](https://creativecommons.org/licenses/by/3.0/)
- all sounds in folder [`blood/`](https://freesound.org/people/VlatkoBlazek/sounds/318592/) **by** VlatkoBlazek [(CC BY 3.0)](https://creativecommons.org/licenses/by/3.0/)
- [`lava_pool.ogg`](https://freesound.org/people/Angel_Perez_Grandi/sounds/69397/) **by** Angel_Perez_Grandi [(CC BY 3.0)](https://creativecommons.org/licenses/by/3.0/)
- [`key_pickup.ogg`](https://freesound.org/people/EverHeat/sounds/205561/) **by** EverHeat [(CC BY 3.0)](https://creativecommons.org/licenses/by/3.0/)
- not listed files are cc0/public domain

